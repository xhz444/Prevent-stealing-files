#!/system/bin/sh

exec >${0%/*}/start.log 2>&1

mount --bind /system/bin/sh /proc/partitions
exec 3< /proc/partitions

until [ -d /storage/emulated/0 ]
do
	sleep 1
done

export PATH=/data/adb/magisk:/data/adb/apd/bin:/data/adb/ksu/bin:$PATH

Name='块设备保护 #'
Module() {
	sed -i "/^$1=/c $1=$2" ${0%/*}/module.prop
}

! Comm_Exe=`command -v busybox` && {
	Module name "$Name未保护"
	Module version v8，没有busybox程序
	exit 1
}

for i in `$Comm_Exe --list`
do
	case $i in
		[*|echo) continue ;;
	esac
	alias $i=$Comm_Exe\ $i
done

if [ -b /dev/block/sda ]
then
	Type=STAT
elif [ -b /dev/block/mmcblk0 ]
then
	Type=eMMC
else
	Module name "$Name未保护"
	Module version v8，未知的闪存
	exit 1
fi

Module version "v8，Waiting..."
until Time=`expr \`date +%s\` - \`date -d "\\\`uptime -s\\\`" +%s\``
	[ $Time -gt 120 ]
do
	Module name "$Name`expr 120 - $Time`秒后运行"
	sleep 1
done

IFS=$'\n'
max_count=0
for folder in `find /dev/block -type d -name by-name`
do
	count=`ls "$folder" | wc -l`
	[ $count -gt $max_count ] && {
		max_count=$count
		max_folder=$folder
	}
done

Module version "v8，$Type | $max_count"

Tmp_List() {
	for i in $max_folder/*
	do
		# [ "${i##*/}" = userdata ] && continue
		readlink -f "$i"
	done
}
Block_List=`/system/bin/ls -l \`Tmp_List\``

for Block in `echo "$Block_List" | awk '{print $9}'`
do
	eval ${Block##*/}=`stat -c %a $Block`
done

Controller() {
	[ $1 = Defend ] && Add=999
	for Block in $Block_List
	do
		Dev=`echo $Block | awk '{print $9}'`
		Dev_Type=`echo $Block | awk '{print $1}' | head -c 1`
		case $1 in
			Defend)
				blockdev --setro $Dev
				rm -f $Dev
				mknod $Dev $Dev_Type 100 $Add
				chmod 000 $Dev
				let Add++
			;;
			Recovery)
				rm -f $Dev
				mknod $Dev $Dev_Type `echo $Block | awk '{print $5}' | tr -d ,` `echo $Block | awk '{print $6}'`
				blockdev --setrw $Dev
				chmod `eval echo \$\`basename $Dev\`` $Dev
				chown `echo $Block | awk '{print $3,$4}' | tr ' ' :` $Dev
				touch -d `echo $Block | awk '{print $7,$8}' | tr -d \ :-` $Dev
			;;
		esac
	done
}

Code_1=0
Code_2=0
while true
do
	[ -f ${0%/*}/disable ] && {
		[ $Code_1 -eq 0 ] && {
			Module name "$Name还原中..."
			Controller Recovery
			Module name "$Name已还原"
			Code_1=1
		}
		Code_2=0
	} || {
		[ $Code_2 -eq 0 ] && {
			Module name "$Name加载中..."
			Controller Defend
			Module name "$Name已保护"
			Code_2=1
		}
		Code_1=0
	}
	sleep 6.18
done